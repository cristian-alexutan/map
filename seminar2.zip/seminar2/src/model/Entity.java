package model;

public interface Entity {
    public int getWeight();
    public String toString();
}
