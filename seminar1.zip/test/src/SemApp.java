import controller.AppController;

public class SemApp {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        AppController appController = new AppController();
        appController.run();
    }
}
